<?php

require_once __DIR__ . '/vendor/autoload.php';

use App\RouterFactory;

$routerFactory = new RouterFactory();
$router = $routerFactory->create();

$application = new Nette\Application\Application();
$application->setRouter($router);

$application->run();