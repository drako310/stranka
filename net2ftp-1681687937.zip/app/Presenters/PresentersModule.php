namespace App\Presenters;

use Nette\Application\UI\Form;

class LoginPresenter extends BasePresenter
{
    public function createComponentLoginForm()
    {
        $form = new Form();

        $form->addText('username', 'Username:')
             ->setRequired('Please enter your username.');

        $form->addPassword('password', 'Password:')
             ->setRequired('Please enter your password.');

        $form->addSubmit('submit', 'Login');

        $form->onSuccess[] = [$this, 'loginFormSucceeded'];

        return $form;
    }

    public function loginFormSucceeded(Form $form, $values)
    {
        try {
            $this->getUser()->login($values->username, $values->password);
            $this->redirect('Homepage:');
        } catch (Nette\Security\AuthenticationException $e) {
            $form->addError($e->getMessage());
        }
    }
}
