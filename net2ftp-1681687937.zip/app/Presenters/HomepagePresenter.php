<?php

declare(strict_types=1);

namespace App\Presenters;

use Nette\Application\UI\Form;

final class HomepagePresenter extends BasePresenter
{
    public function renderDefault(): void
    {
        $this->template->pageTitle = 'Úvodní stránka';
        $this->template->setLayout(__DIR__ . '/../templates/layout.latte');
        $this->template->setFile(__DIR__ . '/../templates/homepage.latte');
    }

    public function actionLogin()
    {
        $this->template->pageTitle = 'Login';
        $this->template->setLayout(__DIR__ . '/../templates/layout.latte');
        $this->template->setFile(__DIR__ . '/../templates/login.latte');
    }

    protected function createComponentLoginForm(): Form
    {
        $form = new Form();
        $form->addText('username', 'Username:')
            ->setRequired('Please enter your username.');
        $form->addPassword('password', 'Password:')
            ->setRequired('Please enter your password.');
        $form->addSubmit('submit', 'Login');
        return $form;
    }
}
