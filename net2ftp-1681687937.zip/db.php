<?php
$servername = "127.0.0.1";
$username = "arlinkcz001";
$password = "W6@fV5w5X2Hp";
$dbname = "arlinkcz";

// Vytvoření připojení
$conn = new mysqli($servername, $username, $password, $dbname);

// Ověření připojení
if ($conn->connect_error) {
    die("Připojení k databázi selhalo: " . $conn->connect_error);
}
?>