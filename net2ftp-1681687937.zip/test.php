<?php
$host = "127.0.0.1"; // připojovací adresa
$username = "arlinkcz001"; // uživatelské jméno
$password = "W6@fV5w5X2Hp"; // heslo
$dbname = "arlinkcz"; // název databáze

// připojení k databázi
$conn = mysqli_connect($host, $username, $password, $dbname);

// kontrola připojení
if (!$conn) {
    die("Připojení k databázi selhalo: " . mysqli_connect_error());
} else {
    echo "Připojení k databázi bylo úspěšné!<br>";

    // vykonání SELECT dotazu
    $sql = "SELECT * FROM nazev_tabulky";
    $result = mysqli_query($conn, $sql);

    // zpracování výsledků
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "ID: " . $row["id"] . " - Jméno: " . $row["jmeno"] . "<br>";
        }
    } else {
        echo "Žádné výsledky.";
    }

    // uzavření spojení s databází
    mysqli_close($conn);
}
?>